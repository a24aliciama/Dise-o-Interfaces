https://color.adobe.com/es/create/color-wheel

##
UI: É algo abstracto que se situa no medio da maquina e do usuario. Calquer elemento que nos permite controlar algun tipo de dispositivo. Interfaz que permite manejar cousas, incluso unha API de java.

UX: user experience. A UI esta incrustado no UX

Front-End: o front end diferenciase do UI en que no front end o usuario non interactua coa pagina, no UI si(por ejemplo un panel de administración)

O conjunto de UI e UX 

## Etapas
1. Análisis
2. Diseño
3. Implementación (programación)
4. Pruebas

### Analisis
Para hacelo necesitaremos saber:
* Usuario
* Necesidades
* Como trabaja ese usuario (flujo)

### Diseño
* Bocetos
* Modelos estilo

### Implementacion
picar codigo

### Pruebas



## truco colores
como son un trenco usar 2 colores principales e escala de grises