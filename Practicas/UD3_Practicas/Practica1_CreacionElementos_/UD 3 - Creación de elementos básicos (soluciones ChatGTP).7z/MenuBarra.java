import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class MenuBarra {
    public static void main(String[] args) {
        JFrame frame = new JFrame("Menú de Barra");
        frame.setSize(300, 200);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Crear la barra de menú
        JMenuBar barraMenu = new JMenuBar();

        // Crear menús
        JMenu menuArchivo = new JMenu("Archivo");
        JMenu menuEdicion = new JMenu("Edición");

        // Crear elementos de menú
        JMenuItem abrirItem = new JMenuItem("Abrir");
        JMenuItem guardarItem = new JMenuItem("Guardar");

        // Añadir acción a los elementos de menú
        abrirItem.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.out.println("Abrir seleccionado");
            }
        });

        guardarItem.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.out.println("Guardar seleccionado");
            }
        });

        // Añadir elementos al menú "Archivo"
        menuArchivo.add(abrirItem);
        menuArchivo.add(guardarItem);

        // Añadir menús a la barra de menú
        barraMenu.add(menuArchivo);
        barraMenu.add(menuEdicion);

        // Añadir la barra de menú a la ventana
        frame.setJMenuBar(barraMenu);

        // Hacer visible la ventana
        frame.setVisible(true);
    }
}

