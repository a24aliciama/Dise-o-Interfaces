import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ToppingsPizza {
    public static void main(String[] args) {
        JFrame frame = new JFrame("Toppings para Pizza");
        frame.setSize(300, 200);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Crear un panel
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));

        // Crear casillas de verificación
        JCheckBox quesoExtra = new JCheckBox("Queso Extra");
        JCheckBox pepperoni = new JCheckBox("Pepperoni");
        JCheckBox aceitunas = new JCheckBox("Aceitunas");

        // Crear botón de ordenar
        JButton botonOrdenar = new JButton("Ordenar");

        // Añadir acción al botón
        botonOrdenar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.out.println("Toppings seleccionados:");
                if (quesoExtra.isSelected()) {
                    System.out.println("- Queso Extra");
                }
                if (pepperoni.isSelected()) {
                    System.out.println("- Pepperoni");
                }
                if (aceitunas.isSelected()) {
                    System.out.println("- Aceitunas");
                }
            }
        });

        // Añadir componentes al panel
        panel.add(new JLabel("Selecciona los toppings:"));
        panel.add(quesoExtra);
        panel.add(pepperoni);
        panel.add(aceitunas);
        panel.add(botonOrdenar);

        // Añadir panel a la ventana
        frame.add(panel);

        // Hacer visible la ventana
        frame.setVisible(true);
    }
}
