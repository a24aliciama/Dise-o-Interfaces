import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class OpcionesDePago {
    public static void main(String[] args) {
        JFrame frame = new JFrame("Opciones de Pago");
        frame.setSize(300, 200);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Crear un panel
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));

        // Crear botones de opción
        JRadioButton tarjetaCredito = new JRadioButton("Tarjeta de Crédito");
        JRadioButton paypal = new JRadioButton("PayPal");
        JRadioButton transferenciaBancaria = new JRadioButton("Transferencia Bancaria");

        // Agrupar los botones de opción
        ButtonGroup grupoOpciones = new ButtonGroup();
        grupoOpciones.add(tarjetaCredito);
        grupoOpciones.add(paypal);
        grupoOpciones.add(transferenciaBancaria);

        // Crear botón de confirmar
        JButton botonConfirmar = new JButton("Confirmar");

        // Añadir acción al botón
        botonConfirmar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (tarjetaCredito.isSelected()) {
                    System.out.println("Opción seleccionada: Tarjeta de Crédito");
                } else if (paypal.isSelected()) {
                    System.out.println("Opción seleccionada: PayPal");
                } else if (transferenciaBancaria.isSelected()) {
                    System.out.println("Opción seleccionada: Transferencia Bancaria");
                }
            }
        });

        // Añadir componentes al panel
        panel.add(new JLabel("Selecciona tu método de pago:"));
        panel.add(tarjetaCredito);
        panel.add(paypal);
        panel.add(transferenciaBancaria);
        panel.add(botonConfirmar);

        // Añadir panel a la ventana
        frame.add(panel);

        // Hacer visible la ventana
        frame.setVisible(true);
    }
}

