import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class MenuDesplegable {
    public static void main(String[] args) {
        JFrame frame = new JFrame("Menú Desplegable");
        frame.setSize(300, 200);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Crear menú desplegable
        String[] colores = { "Rojo", "Verde", "Azul" };
        JComboBox<String> comboColores = new JComboBox<>(colores);

        // Añadir acción al menú desplegable
        comboColores.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String colorSeleccionado = (String) comboColores.getSelectedItem();
                System.out.println("Color seleccionado: " + colorSeleccionado);
            }
        });

        // Añadir el menú desplegable a la ventana
        frame.add(comboColores);

        // Hacer visible la ventana
        frame.setVisible(true);
    }
}
