import javax.swing.JButton;
import javax.swing.JFrame;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class VentanaSimple {
    public static void main(String[] args) {
        // Crear el marco (ventana)
        JFrame frame = new JFrame("Mi primera ventana");
        frame.setSize(300, 200);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Crear un botón
        JButton boton = new JButton("Haz clic aquí");
        
        // Añadir un evento al botón
        boton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.out.println("¡Botón presionado!");
            }
        });

        // Añadir el botón a la ventana
        frame.add(boton);

        // Hacer visible la ventana
        frame.setVisible(true);
    }
}
