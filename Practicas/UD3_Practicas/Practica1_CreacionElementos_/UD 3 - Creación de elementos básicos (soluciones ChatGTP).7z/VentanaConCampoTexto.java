import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class VentanaConCampoTexto {
    public static void main(String[] args) {
        JFrame frame = new JFrame("Ventana con campo de texto");
        frame.setSize(400, 200);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Crear un panel
        JPanel panel = new JPanel();

        // Crear un campo de texto y un botón
        JTextField campoTexto = new JTextField(20);
        JButton boton = new JButton("Mostrar nombre");

        // Añadir acción al botón
        boton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String nombre = campoTexto.getText();
                System.out.println("El nombre ingresado es: " + nombre);
            }
        });

        // Añadir componentes al panel
        panel.add(new JLabel("Escribe tu nombre:"));
        panel.add(campoTexto);
        panel.add(boton);

        // Añadir panel a la ventana
        frame.add(panel);

        // Hacer visible la ventana
        frame.setVisible(true);
    }
}
